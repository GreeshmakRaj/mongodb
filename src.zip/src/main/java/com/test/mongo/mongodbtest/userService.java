package com.test.mongo.mongodbtest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class userService {
	@Autowired
	private userRepo userRepo;
	
	public String createUser(String name, String department, String manager, int age, int salary){
		Users user =  new Users(name, department, manager, age, salary);
		userRepo.save(user);
		return("new empolyee created with id: "+user.getId());
	}
	
	public List<Users> listUsers(){
		return userRepo.findAll();
	}
	
	public String updateUser(String name, String department, String manager, int age, int salary, String id){
		Users new_user = new Users();

		new_user.setName(name);
		new_user.setDepartment(department);
		new_user.setManager(manager);
		new_user.setAge(age);
		new_user.setSalary(salary);
		new_user.setId(id);
		userRepo.save(new_user);
		return("new employee with id "+new_user.getId()+" updated");
		
		
	}

	public String deleteUser(String id) {
		// TODO Auto-generated method stub
		userRepo.deleteById(id);
		return ("user with id "+id+" deleted");
	}

}
