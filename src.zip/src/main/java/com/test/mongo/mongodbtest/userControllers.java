package com.test.mongo.mongodbtest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employee")
public class userControllers {
	
	@Autowired
	private userService userService;
	
	@PostMapping("/add")
	public String createUser(
			@RequestParam("name") String name,
			@RequestParam("dept") String department,
			@RequestParam("manager") String manager,
			@RequestParam("age") int age,
			@RequestParam("salary") int salary
			){
		return userService.createUser(name, department, manager, age, salary);
	}
	
	@GetMapping("/list")
	public List<?> listUsers(){
	
		return userService.listUsers();
		
	}
	
	@PutMapping("/{id}")
	public String updateUser(
			@RequestParam("name") String name,
			@RequestParam("dept") String department,
			@RequestParam("manager") String manager,
			@RequestParam("age") int age,
			@RequestParam("salary") int salary,
			@PathVariable String id
			){
		return userService.updateUser(name, department, manager, age, salary, id);
			}
	
	@DeleteMapping("/{id}")
	public String deleteUser(@PathVariable String id){
		return userService.deleteUser(id);
	}
	
}
